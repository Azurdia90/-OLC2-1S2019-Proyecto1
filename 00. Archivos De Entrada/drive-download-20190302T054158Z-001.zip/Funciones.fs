funcion MensajeBienvenida(var Nombre){
	Imprimir("Bienvenido al registro" + Nombre + " de Creator XML, porfavor ingrese todos sus datos");
}

funcion MensajeDespedida(var NombreCompleto){
	Imprimir("Gracias por registrarse con nosotros " + NombreCompleto);
}